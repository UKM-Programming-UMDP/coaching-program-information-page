import React from "react";
import ConfirmationDialog from "../components/ConfirmationDialog";
import BookFormModal from "../components/BookFormModal";
import BookListItem from "../components/BookListItem";
import useBookList from "../hooks/useBookList";

const BookList = () => {
  const {} = useBookList();
  if (false) {
    return <div className="p-6">Loading books...</div>;
  }

  const books = [
    {
      id: 1,
      title: "Book Title 1",
      author: "Author 1",
      year: 2021,
      isFinished: true,
    },
    {
      id: 2,
      title: "Book Title 2",
      author: "Author 2",
      year: 2020,
      isFinished: false,
    },
  ];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Book Library</h1>
        <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-md focus:outline-none focus:shadow-outline">
          Add New Book
        </button>
      </div>
      {books && books.length > 0 ? (
        <ul className="space-y-3">
          {books.map((book) => (
            <BookListItem key={book.id} book={book} />
          ))}
        </ul>
      ) : (
        <p className="text-gray-600 italic">
          No books available in your library.
        </p>
      )}

      <ConfirmationDialog message="Are you sure you want to delete this book?" />

      <BookFormModal />
    </div>
  );
};

export default BookList;
