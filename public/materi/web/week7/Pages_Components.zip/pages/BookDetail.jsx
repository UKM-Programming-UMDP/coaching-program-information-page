import React from "react";
import BookFormModal from "../components/BookFormModal";
import BookDetailItem from "../components/BookDetailItem"; // Import the new component

const BookDetail = () => {
  if (false) {
    return <div className="p-6">Loading book details...</div>;
  }

  if (false) {
    return <div className="p-6">Book not found.</div>;
  }

  const bookDetailsData = [
    { label: "Author", value: "Book Author" },
    { label: "Year", value: "2021" },
    { label: "Publisher", value: "Book Publisher" },
    { label: "Summary", value: "Book Summary" },
    { label: "Page Count", value: "300" },
    { label: "Read Page", value: "150" },
    { label: "Finished", value: "Yes" },
  ];

  return (
    <div className="p-6">
      <div className="bg-white shadow-md rounded-md p-6">
        <p className="text-3xl font-bold mb-6">Book Title</p>
        {bookDetailsData.map((item, index) => (
          <BookDetailItem
            key={index}
            label={item.label}
            value={item.value}
            className={item.className}
          />
        ))}
        <div className="mt-6 flex justify-end">
          <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
            Update Book
          </button>
        </div>
      </div>

      <BookFormModal />
    </div>
  );
};

export default BookDetail;
